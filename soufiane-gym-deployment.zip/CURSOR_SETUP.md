Cursor setup and deployment

Goal: Ensure the custom gym cursor works reliably when the site is published.

What I added:
- `assets/gym-cursor.svg` — vector logo for the cursor (already in project).
- CSS fallbacks in `styles.css`: prefer `assets/gym-cursor.cur`, then `assets/gym-cursor.svg`, then an inline SVG data-URI, then `assets/gym-cursor.png`, then `auto`.
- `create_cursor.ps1` — PowerShell script to generate `assets/gym-cursor.png` and `assets/gym-cursor.cur` using ImageMagick or Inkscape.

Steps to finalize locally (one-time):
1. Install ImageMagick (recommended) or Inkscape.
2. From the project root, run in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\create_cursor.ps1
```

3. Confirm files `assets/gym-cursor.png` and `assets/gym-cursor.cur` exist.
4. Test the site locally (open `index.html`) and verify the cursor shows.

Notes & browser compatibility:
- Browsers differ in custom-cursor support. A `.cur`/.ico with hotspot coordinates is best for Windows/Chrome/Edge/Firefox. Safari on macOS sometimes rejects custom cursors larger than 128x128.
- The CSS uses a small 32x32 cursor with hotspot `16 16` (center). If you want the pointer tip at a different pixel, re-generate PNG/CUR and adjust the hotspot numbers in `styles.css`.
- If you host with a restrictive Content Security Policy (CSP), ensure `style-src` allows `data:` for the inline SVG fallback or host the files on the same origin.

If you want, I can:
- Run the conversion for you if you provide ImageMagick here (not possible in current environment).
- Create a downloadable `.zip` of the final assets if you want to upload them yourself.
