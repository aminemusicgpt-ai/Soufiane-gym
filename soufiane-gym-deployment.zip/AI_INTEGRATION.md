دليل تفعيل المساعد الذكي الحقيقي (OpenAI) — Soufiane Gym

الهدف: ربط واجهة الموقع بخادم Node.js يقوم بتمرير الطلبات إلى OpenAI، مع توجيهات أمان واختبار.

ملخص سريع:
1. الخادم موجود في `server.js`.
2. ملف إعداد المثال: `.env.example` (انسخه إلى `.env`).
3. الواجهة الأمامية (`script.js`) ترسل الآن طلبات POST إلى `/api/ai`.

الخطوات المحلية (Windows / Mac / Linux):

1) نسخ ملف الإعداد:

```bash
copy .env.example .env   # Windows
# أو
cp .env.example .env     # Mac/Linux
```

2) افتح `.env` وأضف مفتاح OpenAI الخاص بك:

```
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
PORT=3000
```

3) ثبت الحزم وقم بتشغيل الخادم:

```bash
npm install
npm start
```

4) تحقق من حالة الخادم:

```
curl http://localhost:3000/health
# يجب أن تحصل على: { "status": "ok" }
```

5) اختبار نقطة النهاية مباشرة:

```bash
curl -X POST http://localhost:3000/api/ai -H "Content-Type: application/json" -d '{"message":"أريد خطة تدريب للمبتدئين"}'
```

خروج متوقع: JSON مع الخاصية `reply` تحتوي نص الرد.

ملاحظات أمان ونشر:
- لا ترفع `.env` أو `OPENAI_API_KEY` لمستودع عام.
- ضع المتغيرات كـ Environment Variables في خدمة الاستضافة (Vercel, Render, Heroku، الخ).
- إن نشرت الواجهة والـ API على نطاقين منفصلين، فعّل CORS بذكاء وقيد النطاقات المسموح بها.
- لضمان تكلفة معقولة وحماية، ضع قيود على معدل الاستدعاء (rate limiting) أو تحقق من المستخدم قبل السماح.

تخصيصات مقترحة لاحقاً:
- تخزين المحادثات في قاعدة بيانات (SQLite / MongoDB) لتحليل التفاعل.
- إضافة مصادقة وواجهة إدارة.
- تحسين system prompt في `server.js` ليعطي أسلوباً أصيلاً ومحددًا لردود المساعد.

إذا ترغب، أستطيع الآن:
- تشغيل اختبار محلي (لا أستطيع الوصول لشبكتك لكن أشرح الأوامر)
- إضافة حفظ المحادثات عبر ملف JSON/local DB
- إضافة حماية بسيطة بـ API key مخصص للواجهة
