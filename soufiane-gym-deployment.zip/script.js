// Smooth scrolling for navigation links (only for valid in-page anchors)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    const href = anchor.getAttribute('href');
    // ignore plain '#' anchors used as placeholders
    if (!href || href === '#') return;
    anchor.addEventListener('click', function (e) {
        const selector = this.getAttribute('href');
        try {
            const target = document.querySelector(selector);
            if (!target) return; // nothing to scroll to
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            // Update active link
            document.querySelectorAll('.nav-links a').forEach(link => link.classList.remove('active'));
            this.classList.add('active');
        } catch (err) {
            // invalid selector — ignore
            console.warn('Invalid in-page link selector:', selector);
        }
    });
});

// Mobile menu toggle
const menuToggle = document.getElementById('menuToggle');
if (menuToggle) {
    menuToggle.addEventListener('click', function() {
        const navLinks = document.querySelector('.nav-links');
        if (!navLinks) return;
        const isOpen = navLinks.classList.toggle('open');
        menuToggle.setAttribute('aria-expanded', String(isOpen));
    });
}

// Utility: throttle and debounce
function throttle(fn, wait) {
    let last = 0;
    return function(...args) {
        const now = Date.now();
        if (now - last >= wait) {
            last = now;
            fn.apply(this, args);
        }
    };
}

function debounce(fn, wait) {
    let t;
    return function(...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
    };
}

// Close mobile menu when clicking a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        const navLinks = document.querySelector('.nav-links');
        if (navLinks && navLinks.classList.contains('open')) {
            navLinks.classList.remove('open');
            if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
        }
    });
});

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
    const navLinks = document.querySelector('.nav-links');
    const navbar = document.querySelector('.navbar');
    if (navLinks && navbar && !navbar.contains(e.target)) {
        if (navLinks.classList.contains('open')) {
            navLinks.classList.remove('open');
            if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
        }
    }
});

// Logo cursor effect
const logo = document.querySelector('.logo h1');
if (logo) {
    logo.style.cursor = 'pointer';
    logo.addEventListener('click', () => {
        window.scrollTo({top: 0, behavior: 'smooth'});
    });
}

// Navbar style on scroll
const navbar = document.querySelector('.navbar');
function updateNavbarOnScroll() {
    if (!navbar) return;
    navbar.classList.toggle('scrolled', window.scrollY > 10);
}
updateNavbarOnScroll();

// ==================== AI Assistant Functions ====================

// Send quick message
function sendQuickMessage(message) {
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.value = message;
        sendMessage();
    }
}

// Send chat message
async function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    const message = chatInput.value.trim();

    if (!message) return;

    // Add user message (use textContent to avoid HTML injection)
    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'message user-message';
    const userInner = document.createElement('div');
    userInner.textContent = message;
    userMessageDiv.appendChild(userInner);
    chatMessages.appendChild(userMessageDiv);

    chatInput.value = '';

    // Add typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message';
    const iconSpan = document.createElement('span');
    iconSpan.className = 'message-icon';
    iconSpan.textContent = '🤖';
    const typingInner = document.createElement('div');
    typingInner.className = 'typing';
    typingInner.textContent = 'جاري التفكير...';
    typingDiv.appendChild(iconSpan);
    typingDiv.appendChild(typingInner);
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Try calling backend AI endpoint
    try {
        const resp = await fetch('/api/ai', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });

        if (!resp.ok) throw new Error('AI endpoint error');

        const data = await resp.json();
        const reply = (data && (data.reply || data.message)) || 'عذراً، لم أتمكن من إنشاء رد الآن.';

        // replace typing indicator with safe text
        typingDiv.innerHTML = '';
        const replyIcon = document.createElement('span');
        replyIcon.className = 'message-icon';
        replyIcon.textContent = '🤖';
        const replyInner = document.createElement('div');
        replyInner.textContent = reply;
        typingDiv.appendChild(replyIcon);
        typingDiv.appendChild(replyInner);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (err) {
        // Fallback to local simulated responses if backend fails
        const fallback = generateFallbackResponse(message);
        typingDiv.innerHTML = '';
        const replyIcon = document.createElement('span');
        replyIcon.className = 'message-icon';
        replyIcon.textContent = '🤖';
        const replyInner = document.createElement('div');
        replyInner.textContent = fallback;
        typingDiv.appendChild(replyIcon);
        typingDiv.appendChild(replyInner);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        console.warn('AI backend failed, used fallback response.', err);
    }
}

// Local fallback responses (keeps previous simulated logic)
function generateFallbackResponse(message) {
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('تدريب') || lowerMessage.includes('تمرين')) {
        return '💪 أنا هنا لمساعدتك! هل تريد برنامج تدريبي خاص بك؟ يمكنني أن أوصي ببرامج حسب مستواك وأهدافك.';
    } else if (lowerMessage.includes('غذائية') || lowerMessage.includes('أكل') || lowerMessage.includes('طعام')) {
        return '🥗 التغذية السليمة أساس النجاح! هل تريد نصائح غذائية مخصصة أم معلومات عن التغذية الصحيحة؟';
    } else if (lowerMessage.includes('تحمية') || lowerMessage.includes('حرق')) {
        return '🔥 برامج التحمية رائعة لحرق السعرات! أنصحك بدمج تمارين القلب مع تمارين القوة للنتائج الأفضل.';
    } else if (lowerMessage.includes('معلومات') || lowerMessage.includes('عن')) {
        return '📋 معلومات عامة: صالة سوفيان جيم توفر أحدث المعدات والمدربين المحترفين. هل تريد معلومات عن عضويتنا؟';
    } else {
        const responses = [
            '✨ رائع! كيف يمكنني مساعدتك أكثر؟',
            '🎯 هذا خيار ممتاز! هل لديك أسئلة أخرى؟',
            '💯 أنا هنا لدعمك في رحلة لياقتك!',
            '🚀 دعنا نحقق أهدافك معاً!'
        ];
        return responses[Math.floor(Math.random() * responses.length)];
    }
}

// Send button click
const sendBtn = document.getElementById('send-btn');
if (sendBtn) {
    sendBtn.addEventListener('click', sendMessage);
}

// Enter key to send message
const chatInput = document.getElementById('chat-input');
if (chatInput) {
    chatInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

// Form submission
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = this.querySelector('input[type="text"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const phone = this.querySelector('input[type="tel"]').value;
        const message = this.querySelector('textarea').value;
        
        // Show success message
        alert(`شكراً ${name}!\nسيتم التواصل معك قريباً على ${email}`);
        
        // Reset form
        this.reset();
    });
}

// Newsletter form submission
const newsletterForm = document.querySelector('.newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        alert(`شكراً! تم الاشتراك برسالة إلى ${email}`);
        this.reset();
    });
}

// Pricing button handlers
document.querySelectorAll('.price-card .btn').forEach(button => {
    button.addEventListener('click', function() {
        const planName = this.closest('.price-card').querySelector('h3').textContent;
        alert(`تم اختيار ${planName}. سيتم تحويلك لصفحة الدفع.`);
    });
});

// Success stories slider (simple, بدون مبالغة)
(function initSuccessSlider() {
    const slides = document.querySelectorAll('.success-slide');
    const prevBtn = document.getElementById('successPrev');
    const nextBtn = document.getElementById('successNext');

    if (!slides.length || !prevBtn || !nextBtn) return;

    let current = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
    }

    prevBtn.addEventListener('click', () => {
        current = (current - 1 + slides.length) % slides.length;
        showSlide(current);
    });

    nextBtn.addEventListener('click', () => {
        current = (current + 1) % slides.length;
        showSlide(current);
    });

    // إظهار أول سلايد عند التحميل
    showSlide(current);
})();

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe cards (services / classes / pricing) with slight stagger
document.querySelectorAll('.service-card, .class-card, .price-card').forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    card.style.transitionDelay = `${index * 80}ms`;
    observer.observe(card);
});

// Reveal sections on scroll (modern)
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.12 });

document.querySelectorAll('section').forEach(section => {
    section.classList.add('reveal');
    revealObserver.observe(section);
});

// Consolidated throttled scroll handler (navbar, active link, parallax)
const handleScroll = throttle(() => {
    // navbar style
    updateNavbarOnScroll();

    // active nav link
    let current = '';
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (window.scrollY >= (sectionTop - 200)) {
            current = section.getAttribute('id');
        }
    });
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href') || '';
        if (href.slice(1) === current) link.classList.add('active');
    });

    // parallax
    const hero = document.querySelector('.hero');
    if (hero) hero.style.backgroundPosition = `0 ${window.scrollY * 0.5}px`;
}, 100);

window.addEventListener('scroll', handleScroll, { passive: true });

// Counter animation for stats
function animateCounters() {
    const stats = document.querySelectorAll('.stat h3');
    
    stats.forEach(stat => {
        const finalValue = parseInt(stat.textContent);
        let currentValue = 0;
        const increment = finalValue / 50;
        
        const timer = setInterval(() => {
            currentValue += increment;
            if (currentValue >= finalValue) {
                stat.textContent = finalValue + (stat.textContent.includes('+') ? '+' : '');
                clearInterval(timer);
            } else {
                if (stat.textContent.includes('+')) {
                    stat.textContent = Math.ceil(currentValue) + '+';
                } else {
                    stat.textContent = Math.ceil(currentValue);
                }
            }
        }, 30);
    });
}

// Trigger counter animation when stats section is in view
const statsSection = document.querySelector('.about');
if (statsSection) {
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('animated')) {
                animateCounters();
                entry.target.classList.add('animated');
                statsObserver.unobserve(entry.target);
            }
        });
    });
    statsObserver.observe(statsSection);
}

// Add loading animation
window.addEventListener('load', function() {
    const loader = document.getElementById('page-loader');
    // إظهار المحتوى بعد 1.2 ثانية تقريباً
    setTimeout(() => {
        if (loader) {
            loader.classList.add('hidden');
        }
        document.body.style.opacity = '1';
    }, 1200);
});

// Hero particles (lightweight canvas animation)
(function initHeroParticles() {
    const canvas = document.getElementById('heroParticles');
    const hero = document.querySelector('.hero');
    if (!canvas || !hero) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return; // canvas not supported or context unavailable
    const particles = [];
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function resize() {
        const rect = hero.getBoundingClientRect();
        canvas.width = rect.width * window.devicePixelRatio;
        canvas.height = rect.height * window.devicePixelRatio;
        ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    }

    window.addEventListener('resize', debounce(resize, 150));
    resize();

    const colors = ['#00a8ff', '#ff1744', '#4caf50', '#ffffff'];
    const count = prefersReducedMotion ? 15 : 40;

    for (let i = 0; i < count; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            r: 2 + Math.random() * 3,
            speedX: -0.4 + Math.random() * 0.8,
            speedY: -0.3 + Math.random() * 0.6,
            color: colors[Math.floor(Math.random() * colors.length)],
            alpha: 0.3 + Math.random() * 0.5
        });
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // subtle gradient background overlay
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, 'rgba(0, 168, 255, 0.06)');
        gradient.addColorStop(1, 'rgba(255, 23, 68, 0.04)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            ctx.beginPath();
            ctx.fillStyle = `rgba(${hexToRgb(p.color)}, ${p.alpha})`;
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();

            p.x += p.speedX;
            p.y += p.speedY;

            if (p.x < -10) p.x = canvas.width + 10;
            if (p.x > canvas.width + 10) p.x = -10;
            if (p.y < -10) p.y = canvas.height + 10;
            if (p.y > canvas.height + 10) p.y = -10;
        });

            if (!prefersReducedMotion) {
                requestAnimationFrame(draw);
            }
    }

    function hexToRgb(hex) {
        const value = hex.replace('#', '');
        const bigint = parseInt(value.length === 3
            ? value.split('').map(c => c + c).join('')
            : value, 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        return `${r}, ${g}, ${b}`;
    }

    draw();
})();

// 3D tilt effect for cards
function setupTilt(selector) {
    const cards = document.querySelectorAll(selector);
    if (!cards.length) return;

    cards.forEach(card => {
        const strength = 12;
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const rotateY = ((x / rect.width) - 0.5) * strength * -1;
            const rotateX = ((y / rect.height) - 0.5) * strength;
            card.style.transform = `translateY(-6px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) rotateX(0deg) rotateY(0deg)';
        });
    });
}

setupTilt('.service-card');
setupTilt('.class-card');
setupTilt('.price-card');

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + / to show contact form
    if (e.ctrlKey && e.key === '/') {
        e.preventDefault();
        document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
    }
});

// Dark mode toggle (optional feature)
function setupDarkMode() {
    const darkModeToggle = document.createElement('button');
    darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    darkModeToggle.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: var(--primary-color);
        border: none;
        color: white;
        cursor: pointer;
        font-size: 20px;
        z-index: 999;
        display: none;
    `;
    
    document.body.appendChild(darkModeToggle);
    
    darkModeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.innerHTML = document.body.classList.contains('dark-mode') 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    });
}

// Call dark mode setup
setupDarkMode();

// Whatsapp chat button (optional)
function setupWhatsapp() {
    const whatsappBtn = document.createElement('a');
    whatsappBtn.href = 'https://wa.me/+212714550350'; // Replace with your WhatsApp number
    whatsappBtn.innerHTML = '<i class="fab fa-whatsapp"></i>';
    whatsappBtn.style.cssText = `
        position: fixed;
        bottom: 100px;
        right: 30px;
        width: 50px;
        height: 50px;
        background: #25d366;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        z-index: 998;
        text-decoration: none;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transition: all 0.3s ease;
    `;
    
    whatsappBtn.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.1)';
    });
    
    whatsappBtn.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
    
    document.body.appendChild(whatsappBtn);
}

// Call WhatsApp setup
setupWhatsapp();

console.log('Soufiane Gym - Website loaded successfully!');
