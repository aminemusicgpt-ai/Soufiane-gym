const express = require('express');
const axios = require('axios');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Basic hardening
app.disable('x-powered-by');
app.use(helmet());
app.use(cors());
// limit JSON body size to avoid large payloads
app.use(express.json({ limit: '8kb' }));

// Use express-rate-limit for /api routes
const RATE_MAX = parseInt(process.env.RATE_MAX || '200', 10);
const apiLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: RATE_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded' }
});
app.use('/api/', apiLimiter);

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/ai', async (req, res) => {
  const { message } = req.body || {};

  if (!message) {
    return res.status(400).json({ error: 'Missing message in request body' });
  }

  // simple input validation
  if (typeof message !== 'string' || message.length > 2000) {
    return res.status(400).json({ error: 'Invalid message. Must be text under 2000 chars.' });
  }

  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';

  if (!OPENAI_API_KEY) {
    return res.status(503).json({ error: 'OPENAI_API_KEY not configured on server' });
  }

  try {
    // system prompt tailored to be a helpful Arabic fitness coach
    const systemPrompt = `أنت مساعد لياقة بدنيّة محترف يتحدث العربية. قدّم نصائح تدريبية، خطط تمارين، ونصائح غذائية آمنة ومفيدة. اسأل عن مستوى المستخدم وأهدافه قبل إعطاء خطة مفصلة.`;

    const payload = {
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      max_tokens: 600,
      temperature: 0.7
    };

    const response = await axios.post('https://api.openai.com/v1/chat/completions', payload, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      timeout: 20000
    });

    const reply = response.data?.choices?.[0]?.message?.content || '';
    return res.json({ reply });
  } catch (err) {
    console.error('AI request failed:', err?.response?.data || err.message);
    return res.status(502).json({ error: 'AI request failed', detail: err?.response?.data || err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Soufiane Gym AI proxy running on http://localhost:${PORT}`);
});
