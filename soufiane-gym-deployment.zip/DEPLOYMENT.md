# Soufiane Gym — Deployment Guide (Netlify)

## Quick Start

1. **Download the ZIP** from releases or clone the repo.
2. **Install dependencies** (if running backend locally):
   ```bash
   npm install
   ```
3. **Deploy to Netlify**:
   - Option A: Connect your GitHub repo to Netlify (auto-deploy on push)
   - Option B: Use Netlify CLI:
     ```bash
     npm install -g netlify-cli
     netlify deploy --prod
     ```

## Environment Variables

Create a `.env` file in the root (copy from `.env.example`):
```
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
PORT=3000
RATE_MAX=200
```

## Frontend (Static Files)
- `index.html` — Main page
- `styles.css` — Styling
- `script.js` — JavaScript (interactive features)
- `assets/` — Images and cursor files
- Other `.html` files (features, etc.)

## Backend (Node.js/Express)
- `server.js` — Express server with AI endpoint
- `package.json` — Dependencies and scripts

## Netlify Functions (Optional)
To run Node backend on Netlify Serverless:
1. Create `netlify/functions/api.js` with your `/api/*` handlers
2. Or use Netlify's native Node support with `netlify.toml` config

## Linting & QA
```bash
npm run lint:js     # Lint JavaScript
npm run lint:css    # Lint CSS
npm run check       # Run both
npm run dev         # Start dev server (includes backend)
```

## Support
For questions or issues, check `README.md` or `AUDIT_REPORT.md`.
